// End-to-end self-test: boots the real service as a child process with a
// test HMAC secret, then POSTs signed sample tasks for all 7 documented
// cases (1 valid + 6 traps) and asserts decision + reason_code for each.
// Also checks: response signatures, local Groth16 verification of the
// valid case's proof, bad-HMAC rejection, preflight reply, and idempotent
// re-delivery of the same task_id.
//
// Run: npm test

import { spawn } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import * as snarkjs from "snarkjs";
import { signBody, verifyBody, SIGNATURE_HEADER } from "../src/hmac.js";
import { deriveTaskId } from "../src/prove.js";

const SECRET = "selftest-secret-not-a-real-one";
const PORT = 18099;
const BASE = `http://127.0.0.1:${PORT}`;
const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");

const VK = "0x6b79c6012a6d8651f3e13bc4d2a20370280ab49700c90c5316d4168bfbad77b0";
const VK_OTHER = "0x1111111111111111111111111111111111111111111111111111111111111111";
const RECIP = "0xDe429f01De429f01De429f01De429f01De429f01";
const RECIP_OTHER = "0x000000000000000000000000000000000000dead";

let passed = 0;
let failed = 0;
function check(label, cond, extra = "") {
  if (cond) {
    passed++;
    console.log(`  PASS  ${label}`);
  } else {
    failed++;
    console.log(`  FAIL  ${label} ${extra}`);
  }
}

function taskEnvelope(taskId, overrides = {}) {
  const input = {
    registered_vk: VK,
    proof_vk: VK,
    minimum: "1000",
    public_balance: "1460",
    expiry_block: 19842201,
    current_block: 19832000,
    recipient: RECIP,
    condition_recipient: RECIP.toLowerCase(), // case-insensitive match expected
    amount: "500",
    max_transfer: "1000",
    proof_tx: "0xa4c1000000000000000000000000000000000000000000000000000000008ff1",
    ...overrides,
  };
  return {
    type: "agent-games.proof-gatekeeper.v1",
    task_id: taskId,
    mode: "practice",
    issued_at: new Date().toISOString(),
    deadline_at: new Date(Date.now() + 60_000).toISOString(),
    input,
  };
}

async function post(pathname, bodyObj, { sign = true, secret = SECRET } = {}) {
  const raw = JSON.stringify(bodyObj);
  const headers = { "content-type": "application/json" };
  if (sign) headers[SIGNATURE_HEADER] = signBody(raw, secret);
  const res = await fetch(BASE + pathname, { method: "POST", headers, body: raw });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch { /* keep null */ }
  return { status: res.status, json, text, sig: res.headers.get(SIGNATURE_HEADER) };
}

async function waitForHealth() {
  for (let i = 0; i < 50; i++) {
    try {
      const r = await fetch(BASE + "/health");
      if (r.ok) return true;
    } catch { /* not up yet */ }
    await new Promise((r) => setTimeout(r, 200));
  }
  return false;
}

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "chandai-agent-test-"));
const child = spawn("node", ["src/index.js"], {
  cwd: ROOT,
  env: {
    ...process.env,
    PORT: String(PORT),
    AGENT_GAMES_HMAC_SECRET: SECRET,
    SEEN_STORE_PATH: path.join(tmpDir, "seen.json"),
    KURIER_API_KEY: "",
  },
  stdio: ["ignore", "pipe", "pipe"],
});
child.stderr.on("data", (d) => process.stderr.write(`[server] ${d}`));

try {
  check("server becomes healthy", await waitForHealth());

  // --- Preflight -----------------------------------------------------------
  const pre = await post("/agent", { type: "agent-games.preflight.v1" });
  check("preflight returns ok/v1", pre.status === 200 && pre.json?.ok === true && pre.json?.protocolVersion === "v1");
  check("preflight response is signed", Boolean(pre.sig) && verifyBody(pre.text, pre.sig, SECRET));

  // --- Bad HMAC ------------------------------------------------------------
  const bad = await post("/agent", taskEnvelope("gk_t_bad"), { secret: "wrong-secret" });
  check("bad HMAC rejected with 401", bad.status === 401);

  // --- Case 1: VALID_CONDITION --------------------------------------------
  const t1 = taskEnvelope("gk_t_valid");
  const r1 = await post("/agent", t1);
  check("valid -> APPROVE/VALID_CONDITION", r1.json?.decision === "APPROVE" && r1.json?.reason_code === "VALID_CONDITION", JSON.stringify(r1.json));
  check("valid -> proof attached", Boolean(r1.json?.proof && Array.isArray(r1.json?.public_signals)));
  check("valid -> response signature valid", Boolean(r1.sig) && verifyBody(r1.text, r1.sig, SECRET));
  check("valid -> proof_tx echoed", r1.json?.proof_tx === t1.input.proof_tx);
  if (r1.json?.proof) {
    const vk = JSON.parse(fs.readFileSync(path.join(ROOT, "circuits", "verification_key.json"), "utf8"));
    const ok = await snarkjs.groth16.verify(vk, r1.json.public_signals, r1.json.proof);
    check("valid -> Groth16 proof verifies locally", ok === true);
    check("valid -> public_signals[11] is decision=1", r1.json.public_signals[11] === "1");
    check("valid -> public_signals[12] is derived taskId", r1.json.public_signals[12] === deriveTaskId("gk_t_valid"));
  }

  // --- Idempotent re-delivery (same task_id) --------------------------------
  const r1b = await post("/agent", t1);
  check("re-delivered task_id returns cached APPROVE", r1b.json?.decision === "APPROVE" && r1b.json?.reason_code === "VALID_CONDITION");

  // --- Case 2: VK_SUBSTITUTION ----------------------------------------------
  const r2 = await post("/agent", taskEnvelope("gk_t_vk", { proof_vk: VK_OTHER, proof_tx: "0xb100000000000000000000000000000000000000000000000000000000000001" }));
  check("vk substitution -> REJECT/VK_SUBSTITUTION", r2.json?.decision === "REJECT" && r2.json?.reason_code === "VK_SUBSTITUTION", JSON.stringify(r2.json));
  check("vk substitution -> proof attached", Boolean(r2.json?.proof));

  // --- Case 3: THRESHOLD_MISMATCH -------------------------------------------
  const r3 = await post("/agent", taskEnvelope("gk_t_threshold", { public_balance: "999", proof_tx: "0xb200000000000000000000000000000000000000000000000000000000000002" }));
  check("threshold -> REJECT/THRESHOLD_MISMATCH", r3.json?.decision === "REJECT" && r3.json?.reason_code === "THRESHOLD_MISMATCH", JSON.stringify(r3.json));
  check("threshold -> proof attached", Boolean(r3.json?.proof));

  // --- Case 4: PROOF_REUSED (same proof_tx as case 1, new task_id) ----------
  const r4 = await post("/agent", taskEnvelope("gk_t_reused"));
  check("reused proof -> REJECT/PROOF_REUSED", r4.json?.decision === "REJECT" && r4.json?.reason_code === "PROOF_REUSED", JSON.stringify(r4.json));
  check("reused proof -> no proof attached (no witness exists)", r4.json?.proof === null);

  // --- Case 5: EXPIRED_CONDITION --------------------------------------------
  const r5 = await post("/agent", taskEnvelope("gk_t_expired", { current_block: 19842202, proof_tx: "0xb500000000000000000000000000000000000000000000000000000000000005" }));
  check("expired -> REJECT/EXPIRED_CONDITION", r5.json?.decision === "REJECT" && r5.json?.reason_code === "EXPIRED_CONDITION", JSON.stringify(r5.json));
  check("expired -> proof attached", Boolean(r5.json?.proof));

  // --- Case 6: RECIPIENT_MISMATCH -------------------------------------------
  const r6 = await post("/agent", taskEnvelope("gk_t_recipient", { condition_recipient: RECIP_OTHER, proof_tx: "0xb600000000000000000000000000000000000000000000000000000000000006" }));
  check("recipient -> REJECT/RECIPIENT_MISMATCH", r6.json?.decision === "REJECT" && r6.json?.reason_code === "RECIPIENT_MISMATCH", JSON.stringify(r6.json));
  check("recipient -> proof attached", Boolean(r6.json?.proof));

  // --- Case 7: AMOUNT_OVERFLOW ----------------------------------------------
  const r7 = await post("/agent", taskEnvelope("gk_t_amount", { amount: "1001", proof_tx: "0xb700000000000000000000000000000000000000000000000000000000000007" }));
  check("amount -> REJECT/AMOUNT_OVERFLOW", r7.json?.decision === "REJECT" && r7.json?.reason_code === "AMOUNT_OVERFLOW", JSON.stringify(r7.json));
  check("amount -> proof attached", Boolean(r7.json?.proof));
} finally {
  child.kill("SIGTERM");
  fs.rmSync(tmpDir, { recursive: true, force: true });
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed === 0 ? 0 : 1);
