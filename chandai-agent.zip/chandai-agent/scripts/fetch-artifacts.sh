#!/usr/bin/env bash
# Download the official gatekeeper circuit artifacts and export the
# verification key. The artifacts are small (wasm ~1.8 MB, zkey ~0.3 MB),
# so they are committed to the repo; this script refreshes them.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p circuits
BASE="https://agentgames.zkverify.io/circuits"
echo "Fetching circuit info..."
curl -fsSL "https://agentgames.zkverify.io/api/circuit-info"
echo
curl -fsSL -o circuits/gatekeeper.wasm "$BASE/gatekeeper.wasm"
curl -fsSL -o circuits/gatekeeper_final.zkey "$BASE/gatekeeper_final.zkey"
npx snarkjs zkey export verificationkey circuits/gatekeeper_final.zkey circuits/verification_key.json
ls -la circuits/
